public class TestEmployee {
    public static void main(String args[]){
        Employee e = new Employee("Ram", 1995, 43300.67, 2018, "LIC2018000731738");
        System.out.println(e.getEmployee());
    }
}
